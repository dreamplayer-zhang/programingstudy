**Project Description**
Although WPF provides quite a rich collection of UI controls and components for   development, a particular control has been missing. That is a color-picker control. Here   a drop down style custom color picker has been made using WPF.  

![](Home_default.png)
{"Fig 1: Default colors in Drop Down Style Custom Color Picker"}



![](Home_custom.jpg) 
Fig 2: Custom colors in Drop Down Style Custom Color Picker

Features of this Color Picker:

1.	You can select colors from a default color list.
2.	You can make color from a color image.
3.	You can make color from RGB value.
4.	You can make color from Hex value.

I have published a new article on this on CodeProject;
[http://www.codeproject.com/KB/WPF/WPFDropDownColorPicker.aspx](http://www.codeproject.com/KB/WPF/WPFDropDownColorPicker.aspx)

Here color picker project is provided as class library. To use the color picker, add the color picker class library project as reference in your project and write the following XAML code to include the color picker.
xmlns:cp="clr-namespace:DropDownCustomColorPicker;assembly=CustomColorPicker"
<cp:CustomColorPicker    Width="40" x:Name="customCP"></cp:CustomColorPicker>